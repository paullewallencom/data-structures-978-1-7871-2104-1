package main.java;

/**
 * Created by William Smith on 10/4/16.
 */
public class HeapNode {
    public int Data;
}
