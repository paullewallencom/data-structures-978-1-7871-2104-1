//
//  EDSIntegerTypes.h
//  EverydayDataStructures
//
//  Created by William Smith on 8/4/16.
//  Copyright © 2016 William Smith. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EDSIntegerTypes : NSObject

+ (void)intDemo;

@end
