//
//  EDSStringType.h
//  EverydayDataStructures
//
//  Created by William Smith on 8/11/16.
//  Copyright © 2016 Websmiths, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EDSStringType : NSObject

+(void)stringDemo;

@end
