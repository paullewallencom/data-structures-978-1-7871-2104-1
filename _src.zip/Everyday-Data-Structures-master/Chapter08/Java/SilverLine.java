package main.java;

/**
 * Created by William Smith on 9/19/16.
 */

public enum SilverLine {
    Wiehle_Reston_East,
    Spring_Hill,
    Greensboro,
    Tysons_Corner,
    McClean,
    East_Falls_Church,
    Ballston_MU,
    Virginia_Sq_GMU,
    Clarendon,
    Courthouse,
    Rosslyn,
    Foggy_Bottom_GWU,
    Farragut_West,
    McPherson_Sq,
    Metro_Center,
    Federal_Triangle,
    Smithsonian,
    LEnfant_Plaza,
    Federal_Center_SW,
    Capital_South,
    Eastern_Market,
    Potomac_Ave,
    Stadium_Armory,
    Benning_Road,
    Capital_Heights,
    Addison_Road,
    Morgan_Blvd,
    Largo_Town_Center;

    public static int intValue() {
        //Map the string to an int
        return 0;
    }
}
